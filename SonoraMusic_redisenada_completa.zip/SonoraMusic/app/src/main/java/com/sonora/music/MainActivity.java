package com.sonora.music;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.util.LruCache;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.Build;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    LinearLayout root, content, tracksList, playerPanel, tabs;
    TextView nowTitle, nowSub, playButton, status;
    EditText searchBox;
    MediaPlayer player;
    ArrayList<Track> library = new ArrayList<>(), onlineResults = new ArrayList<>();
    static class Playlist { String name; ArrayList<String> keys=new ArrayList<>(); Playlist(String n){name=n;} }
    ArrayList<Playlist> playlists = new ArrayList<>();
    int current = -1;
    boolean playing = false;
    String page = "home";
    final ExecutorService network = Executors.newSingleThreadExecutor();
    int bg=Color.rgb(11,14,31), panel=Color.rgb(27,32,59), purple=Color.rgb(141,91,255), mint=Color.rgb(89,241,204), muted=0xffaab2d2;
    static final String JAMENDO_CLIENT_ID = "YOUR_JAMENDO_CLIENT_ID"; // Set this in MainActivity.java to enable licensed catalog search.
    private static final LruCache<String, Bitmap> COVER_CACHE = new LruCache<String, Bitmap>(6 * 1024 * 1024) { @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); } };
    static class Track {
        String title, artist, url, source, art; Uri uri; boolean favorite;
        Track(String t,String a,Uri u,String s,String src){this(t,a,u,s,src,"");}
        Track(String t,String a,Uri u,String s,String src,String art){title=t;artist=a;uri=u;url=s;source=src;this.art=art==null?"":art;}
    }
    private final BroadcastReceiver playbackReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){String state=i.getStringExtra("state");String title=i.getStringExtra("title");String artist=i.getStringExtra("artist");String source=i.getStringExtra("source");if(title!=null&&nowTitle!=null){nowTitle.setText(title);nowSub.setText((artist==null?"":artist)+"  •  "+(source==null?"SONORA":source));}current=i.getIntExtra("index",current);playing="playing".equals(state);if(playButton!=null)playButton.setText(playing?"Ⅱ":"loading".equals(state)?"…":"▶");if("error".equals(state)){String err=i.getStringExtra("error");Toast.makeText(MainActivity.this,err==null?"Error de reproducción":err,Toast.LENGTH_LONG).show();if(playButton!=null)playButton.setText("▶");}else if("recovering".equals(state)){Toast.makeText(MainActivity.this,"La pista falló; intentando la siguiente…",Toast.LENGTH_SHORT).show();}}};
    @Override public void onCreate(Bundle b){super.onCreate(b);int theme=getPreferences(0).getInt("theme",0);if(theme==1){bg=0xff10091f;panel=0xff25153d;purple=0xffb35cff;mint=0xff66f5dc;muted=0xffc5b7df;}else if(theme==2){bg=0xff000000;panel=0xff101010;purple=0xffa875ff;mint=0xff72ffe1;muted=0xffdddddd;}getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);loadLibrary();loadPlaylists();showApp();IntentFilter f=new IntentFilter(MediaPlaybackService.BROADCAST);if(Build.VERSION.SDK_INT>=33)registerReceiver(playbackReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(playbackReceiver,f);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},31);} }
    GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);return d;}
    TextView txt(String s,int z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout.LayoutParams lp(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(0,top,0,bottom);return p;}
    Button btn(String s,int c,int tc){Button b=new Button(this);b.setText(s);b.setTextColor(tc);b.setTextSize(14);b.setAllCaps(false);b.setTypeface(null,Typeface.BOLD);b.setBackground(shape(c,18));return b;}
    void showApp(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(20,18,20,26);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{bg,0xff211642}));scroll.addView(root);setContentView(scroll);
        LinearLayout topbar=new LinearLayout(this);topbar.setGravity(Gravity.CENTER_VERTICAL);root.addView(topbar,lp(-1,46,0,6));
        Button menuBtn=btn("☰",panel,Color.WHITE);menuBtn.setTextSize(20);topbar.addView(menuBtn,new LinearLayout.LayoutParams(46,44));
        TextView logo=txt("  ◉ SONORA",19,mint,true);topbar.addView(logo,new LinearLayout.LayoutParams(0,-2,1));
        Button settingsBtn=btn("⚙",panel,Color.WHITE);settingsBtn.setTextSize(19);topbar.addView(settingsBtn,new LinearLayout.LayoutParams(46,44));
        menuBtn.setOnClickListener(v->showMainMenu(menuBtn));settingsBtn.setOnClickListener(v->showSettings());
        TextView headline=txt("El sonido de\ntu mundo.",34,Color.WHITE,true);headline.setPadding(0,10,0,4);root.addView(headline);
        root.addView(txt("DESCUBRE  ·  ESCUCHA  ·  REPITE",12,muted,true));
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(1);hero.setPadding(20,20,20,20);hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{purple,0xff5038b8}));((GradientDrawable)hero.getBackground()).setCornerRadius(26);root.addView(hero,lp(-1,-2,22,18));
        hero.addView(txt("✦  TU ESPACIO MUSICAL",12,Color.WHITE,true));
        hero.addView(txt("Tu música, a tu manera",23,Color.WHITE,true));
        TextView heroSub=txt("Tus canciones y radios favoritas, reunidas en una experiencia premium.",14,0xfff0eaff,false);heroSub.setPadding(0,7,0,0);hero.addView(heroSub);
        tabs=new LinearLayout(this);tabs.setOrientation(0);tabs.setPadding(4,4,4,4);tabs.setBackground(shape(0xff202442,18));root.addView(tabs,lp(-1,52,0,18));
        addTab("Inicio","home");addTab("Radio","radio");addTab("Explorar","catalog");addTab("Biblioteca","library");addTab("Listas","playlists");
        content=new LinearLayout(this);content.setOrientation(1);root.addView(content);
        playerPanel=new LinearLayout(this);playerPanel.setOrientation(1);playerPanel.setPadding(16,14,16,12);playerPanel.setBackground(shape(0xff242747,22));root.addView(playerPanel,lp(-1,-2,22,0));
        nowTitle=txt("Elige una canción",15,Color.WHITE,true);playerPanel.addView(nowTitle);
        nowSub=txt("SONORA PLAYER",11,mint,true);nowSub.setPadding(0,4,0,0);playerPanel.addView(nowSub);
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL);playerPanel.addView(controls,lp(-1,48,8,0));
        Button prev=btn("‹",0xff363a61,Color.WHITE);controls.addView(prev,new LinearLayout.LayoutParams(54,46));prev.setOnClickListener(v->serviceAction(MediaPlaybackService.ACTION_PREV));
        playButton=txt("▶",24,mint,true);playButton.setGravity(Gravity.CENTER);controls.addView(playButton,new LinearLayout.LayoutParams(0,46,1));playButton.setOnClickListener(v->toggle());
        Button next=btn("›",0xff363a61,Color.WHITE);controls.addView(next,new LinearLayout.LayoutParams(54,46));next.setOnClickListener(v->serviceAction(MediaPlaybackService.ACTION_NEXT));
        Button queueButton=btn("☷  Cola de reproducción     ⤢ Abrir reproductor",0xff303454,Color.WHITE);playerPanel.addView(queueButton,lp(-1,42,8,0));queueButton.setOnClickListener(v->{page="player";renderPage();});
        renderPage();
    }
    void addTab(String label,String key){Button b=btn(label,0xff202442,Color.WHITE);b.setTextSize(11);tabs.addView(b,new LinearLayout.LayoutParams(0,-1,1));b.setOnClickListener(v->{page=key;renderPage();});}
    void showMainMenu(View anchor){PopupMenu m=new PopupMenu(this,anchor);String[] labels={"Inicio","Explorar catálogo","Música local","Radio en vivo","Listas de reproducción","Favoritos","Reproductor","Descargas y música sin conexión","Perfil","Configuración","Cerrar menú"};String[] keys={"home","catalog","library","radio","playlists","favorites","player","downloads","profile","settings",""};for(int i=0;i<labels.length;i++){final String k=keys[i];m.getMenu().add(labels[i]).setOnMenuItemClickListener(item->{if(k.isEmpty())return true;if(k.equals("favorites")){showFavorites();return true;}page=k;renderPage();return true;});}m.show();}
    void renderPage(){
        content.removeAllViews();
        if(!page.equals("home")){
            LinearLayout pageTools=new LinearLayout(this);pageTools.setGravity(Gravity.CENTER_VERTICAL);
            TextView brand=txt("SONORA",13,mint,true);pageTools.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
            Button close=btn("✕  Cerrar",0xff292d4d,Color.WHITE);close.setTextSize(12);
            pageTools.addView(close,new LinearLayout.LayoutParams(-2,40));
            content.addView(pageTools,lp(-1,42,0,8));
            close.setOnClickListener(v->{page="home";renderPage();});
        }
        if(page.equals("home")){
            content.addView(txt("Escucha a tu manera",21,Color.WHITE,true));
            content.addView(txt("Elige por dónde empezar.",14,muted,false),lp(-1,-2,4,16));
            addAction("♫","Tu música","Reproduce archivos guardados en el teléfono",()->pickLocal());
            addAction("◉","Radio en vivo","Explora emisoras por género o país",()->{page="radio";renderPage();});
            addAction("⌕","Catálogo musical","Busca música con licencia en Jamendo",()->{page="catalog";renderPage();});
            addAction("☷","Listas de reproducción","Crea y organiza tus propias listas",()->{page="playlists";renderPage();});
            content.addView(txt("Tus favoritos",17,Color.WHITE,true),lp(-1,-2,18,8));
            boolean anyFav=false; for(int i=0;i<library.size();i++) if(library.get(i).favorite){addTrackRow(library.get(i),i,false);anyFav=true;}
            if(!anyFav)content.addView(txt("Marca canciones con ☆ para tenerlas a mano.",12,muted,false),lp(-1,-2,2,8));
            content.addView(txt("Añadido recientemente",17,Color.WHITE,true),lp(-1,-2,14,8));
            if(library.isEmpty())content.addView(txt("Tu biblioteca está esperando su primera canción.",13,muted,false));
            else for(int i=Math.max(0,library.size()-3);i<library.size();i++)addTrackRow(library.get(i),i,false);
            addAction("⚙","Privacidad y ajustes","Gestiona tus datos guardados en este dispositivo",()->showSettings());
        } else if(page.equals("library")){
            content.addView(txt("Tu biblioteca",24,Color.WHITE,true));
            content.addView(txt("Archivos locales y música que hayas añadido.",14,muted,false),lp(-1,-2,4,14));
            Button add=btn("＋  Importar canciones",purple,Color.WHITE);content.addView(add,lp(-1,52,0,14));add.setOnClickListener(v->pickLocal());
            if(library.isEmpty())content.addView(txt("Aún no hay canciones. Importa audio desde tu dispositivo.",14,muted,false));
            else for(int i=0;i<library.size();i++)addTrackRow(library.get(i),i,false);
        } else if(page.equals("radio")) renderRadio();
        else if(page.equals("settings")) showSettingsContent();
        else if(page.equals("playlists")) renderPlaylists();
        else if(page.equals("player")) renderFullPlayer();
        else if(page.equals("favorites")) renderFavorites();
        else if(page.equals("downloads")) renderDownloads();
        else if(page.equals("profile")) renderProfile();
        else renderCatalog();
    }
    void renderDownloads(){content.addView(txt("Descargas y modo sin conexión",23,Color.WHITE,true));content.addView(txt("SONORA reproduce archivos de audio guardados en tu teléfono incluso sin Internet.",13,muted,false),lp(-1,-2,5,14));addAction("♫","Importar música local","Selecciona archivos de audio de tu dispositivo",()->pickLocal());content.addView(txt("Tu música disponible",16,Color.WHITE,true),lp(-1,-2,14,8));if(library.isEmpty())content.addView(txt("Aún no hay canciones importadas. Selecciona Importar música local para empezar.",13,muted,false));else for(int i=0;i<library.size();i++)if("LOCAL".equals(library.get(i).source)||library.get(i).uri!=null)addTrackRow(library.get(i),i,false);}
    void renderProfile(){content.addView(txt("Perfil y cuenta",24,Color.WHITE,true));content.addView(txt("SONORA funciona sin cuenta. Tus listas, favoritos y biblioteca se guardan en este dispositivo.",14,muted,false),lp(-1,-2,6,16));settingsRow("◉","Usuario local","Sin iniciar sesión",()->new AlertDialog.Builder(this).setTitle("Perfil local").setMessage("No necesitas una cuenta para escuchar música local, usar favoritos o crear listas.").setPositiveButton("Cerrar",null).show());settingsRow("♡","Tus favoritos","Gestiona tus canciones guardadas",()->showFavorites());settingsRow("☷","Tus listas","Crea y organiza tus listas de reproducción",()->{page="playlists";renderPage();});Button close=btn("Cerrar perfil",panel,Color.WHITE);content.addView(close,lp(-1,46,8,0));close.setOnClickListener(v->{page="home";renderPage();});}
    void renderFavorites(){content.addView(txt("Tus favoritos",25,Color.WHITE,true));content.addView(txt("Tus canciones guardadas en un solo lugar.",13,muted,false),lp(-1,-2,4,12));boolean found=false;for(int i=0;i<library.size();i++)if(library.get(i).favorite){addTrackRow(library.get(i),i,false);found=true;}if(!found)content.addView(txt("Todavía no tienes favoritos. Pulsa ☆ en una canción para guardarla.",14,muted,false));}
    void renderFullPlayer(){
        content.addView(txt("AHORA REPRODUCIENDO",11,mint,true));
        FrameLayout artBox=new FrameLayout(this);artBox.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff402080,0xff071b43,0xff132d51}));content.addView(artBox,lp(-1,270,16,18));TextView art=txt("♫",76,mint,true);art.setGravity(Gravity.CENTER);artBox.addView(art,new FrameLayout.LayoutParams(-1,-1));
        content.addView(txt(current>=0&&current<library.size()?library.get(current).title:"Elige una canción",23,Color.WHITE,true),lp(-1,-2,4,3));content.addView(txt(current>=0&&current<library.size()?library.get(current).artist:"Tu música te espera",14,muted,false),lp(-1,-2,0,16));
        SeekBar seek=new SeekBar(this);seek.setProgressTintList(android.content.res.ColorStateList.valueOf(mint));content.addView(seek,lp(-1,32,0,6));LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);content.addView(controls,lp(-1,70,0,12));Button prev=btn("|◀",panel,Color.WHITE),toggle=btn(playing?"Ⅱ":"▶",purple,Color.WHITE),next=btn("▶|",panel,Color.WHITE);controls.addView(prev,new LinearLayout.LayoutParams(64,54));controls.addView(toggle,new LinearLayout.LayoutParams(86,58));controls.addView(next,new LinearLayout.LayoutParams(64,54));prev.setOnClickListener(v->serviceAction(MediaPlaybackService.ACTION_PREV));next.setOnClickListener(v->serviceAction(MediaPlaybackService.ACTION_NEXT));toggle.setOnClickListener(v->toggle());Button queue=btn("☷  Ver cola",panel,Color.WHITE);content.addView(queue,lp(-1,46,8,8));queue.setOnClickListener(v->showQueueDialog());Button fav=btn("♡  Gestionar favoritos",panel,mint);content.addView(fav,lp(-1,46,0,8));fav.setOnClickListener(v->showFavorites());
    }
    String trackKey(Track t){return t.uri!=null?"uri:"+t.uri.toString():"url:"+(t.url==null?t.title:t.url);}
    void savePlaylists(){
        try{JSONArray a=new JSONArray();for(Playlist p:playlists){JSONObject o=new JSONObject();o.put("name",p.name);JSONArray k=new JSONArray();for(String key:p.keys)k.put(key);o.put("keys",k);a.put(o);}getSharedPreferences("sonora_playlists",MODE_PRIVATE).edit().putString("items",a.toString()).apply();}catch(Exception ignored){}
    }
    void loadPlaylists(){
        try{JSONArray a=new JSONArray(getSharedPreferences("sonora_playlists",MODE_PRIVATE).getString("items","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Playlist p=new Playlist(o.optString("name","Mi lista"));JSONArray k=o.optJSONArray("keys");if(k!=null)for(int j=0;j<k.length();j++)p.keys.add(k.optString(j));playlists.add(p);}}catch(Exception ignored){}
    }
    void createPlaylistDialog(Track initial){
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Nombre de la lista");input.setTextColor(Color.WHITE);input.setHintTextColor(muted);input.setPadding(18,12,18,12);input.setBackground(shape(panel,14));
        LinearLayout wrap=new LinearLayout(this);wrap.setPadding(20,8,20,4);wrap.addView(input,new LinearLayout.LayoutParams(-1,52));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Crear lista").setView(wrap).setNegativeButton("Cancelar",null).setPositiveButton("Crear",null).create();
        dialog.setOnShowListener(v->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(w->{String name=input.getText().toString().trim();if(name.isEmpty()){input.setError("Escribe un nombre");return;}Playlist p=new Playlist(name);if(initial!=null)p.keys.add(trackKey(initial));playlists.add(p);savePlaylists();dialog.dismiss();if(page.equals("playlists"))renderPage();Toast.makeText(this,"Lista creada",Toast.LENGTH_SHORT).show();});});dialog.show();
    }
    void addTrackToPlaylist(Track track){
        if(playlists.isEmpty()){new AlertDialog.Builder(this).setTitle("Agregar a lista").setMessage("Todavía no tienes listas. ¿Quieres crear una?").setNegativeButton("Cancelar",null).setPositiveButton("Crear lista",(d,w)->createPlaylistDialog(track)).show();return;}
        String[] names=new String[playlists.size()+1];for(int i=0;i<playlists.size();i++)names[i]=playlists.get(i).name;names[names.length-1]="＋ Crear nueva lista";
        new AlertDialog.Builder(this).setTitle("Agregar a lista").setItems(names,(d,which)->{if(which==playlists.size()){createPlaylistDialog(track);return;}Playlist p=playlists.get(which);String key=trackKey(track);if(!p.keys.contains(key))p.keys.add(key);savePlaylists();Toast.makeText(this,"Añadida a "+p.name,Toast.LENGTH_SHORT).show();}).setNegativeButton("Cerrar",null).show();
    }
    void showTrackMenu(Track track){
        PopupMenu menu=new PopupMenu(this,content);
        menu.getMenu().add("Agregar a lista").setOnMenuItemClickListener(i->{addTrackToPlaylist(track);return true;});
        menu.getMenu().add(track.favorite?"Quitar de favoritos":"Añadir a favoritos").setOnMenuItemClickListener(i->{track.favorite=!track.favorite;if(!containsTrack(track))library.add(track);saveLibrary();renderPage();return true;});
        menu.getMenu().add("Información").setOnMenuItemClickListener(i->{new AlertDialog.Builder(this).setTitle(track.title).setMessage(track.artist+"\\nOrigen: "+track.source).setPositiveButton("Cerrar",null).show();return true;});
        menu.getMenu().add("Cerrar menú");
        menu.show();
    }
    void renderPlaylists(){
        content.addView(txt("Listas de reproducción",24,Color.WHITE,true));
        content.addView(txt("Organiza tu música como quieras.",13,muted,false),lp(-1,-2,4,14));
        Button create=btn("＋  Crear nueva lista",purple,Color.WHITE);content.addView(create,lp(-1,48,0,14));create.setOnClickListener(v->createPlaylistDialog(null));
        if(playlists.isEmpty())content.addView(txt("Todavía no hay listas. Crea una y agrega canciones desde el menú ⋮ de cada pista.",13,muted,false),lp(-1,-2,4,10));
        for(Playlist p:new ArrayList<>(playlists)){
            LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(14,12,10,12);card.setBackground(shape(panel,17));content.addView(card,lp(-1,-2,0,9));
            TextView ico=txt("♫",24,mint,true);card.addView(ico,new LinearLayout.LayoutParams(42,42));
            LinearLayout labels=new LinearLayout(this);labels.setOrientation(1);labels.setPadding(10,0,0,0);card.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
            labels.addView(txt(p.name,15,Color.WHITE,true));labels.addView(txt(p.keys.size()+" canciones",12,muted,false));
            Button more=btn("⋮",0xff303454,Color.WHITE);card.addView(more,new LinearLayout.LayoutParams(42,42));more.setOnClickListener(v->{PopupMenu m=new PopupMenu(this,more);m.getMenu().add("Ver canciones").setOnMenuItemClickListener(it->{showPlaylistTracks(p);return true;});m.getMenu().add("Eliminar lista").setOnMenuItemClickListener(it->{new AlertDialog.Builder(this).setTitle("Eliminar lista").setMessage("¿Eliminar “"+p.name+"”? Los archivos de música no se borrarán.").setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(d,w)->{playlists.remove(p);savePlaylists();renderPage();}).show();return true;});m.getMenu().add("Cerrar menú");m.show();});
            card.setOnClickListener(v->showPlaylistTracks(p));
        }
    }
    void showPlaylistTracks(Playlist p){
        ArrayList<Track> matches=new ArrayList<>();for(Track t:library)if(p.keys.contains(trackKey(t)))matches.add(t);
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(16,4,16,4);
        if(matches.isEmpty())box.addView(txt("Esta lista está vacía. Usa el menú ⋮ de una canción para agregarla.",13,muted,false));
        else for(Track t:matches){Button b=btn("▶  "+t.title+" — "+t.artist,0xff202442,Color.WHITE);box.addView(b,lp(-1,46,0,6));b.setOnClickListener(v->{playTrack(t);});}
        ScrollView sc=new ScrollView(this);sc.addView(box);
        new AlertDialog.Builder(this).setTitle(p.name).setView(sc).setPositiveButton("Cerrar",null).setNeutralButton("Agregar canción",(d,w)->chooseTrackForPlaylist(p)).show();
    }
    void chooseTrackForPlaylist(Playlist p){
        if(library.isEmpty()){new AlertDialog.Builder(this).setTitle("Biblioteca vacía").setMessage("Importa canciones primero desde Tu música local.").setPositiveButton("Cerrar",null).show();return;}
        String[] names=new String[library.size()];for(int i=0;i<library.size();i++)names[i]=library.get(i).title+" — "+library.get(i).artist;
        new AlertDialog.Builder(this).setTitle("Agregar canción a "+p.name).setItems(names,(d,which)->{String key=trackKey(library.get(which));if(!p.keys.contains(key))p.keys.add(key);savePlaylists();Toast.makeText(this,"Canción añadida",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cerrar",null).show();
    }
    void showSettings(){page="settings";renderPage();}
    void showSettingsContent(){
        content.addView(txt("Configuración",25,Color.WHITE,true));content.addView(txt("Personaliza tu experiencia SONORA.",13,muted,false),lp(-1,-2,4,16));
        settingsRow("◉","Apariencia","Tema oscuro premium",()->new AlertDialog.Builder(this).setTitle("Apariencia").setSingleChoiceItems(new String[]{"Oscuro (recomendado)","Violeta nocturno","Alto contraste"},getPreferences(0).getInt("theme",0),(d,w)->{getPreferences(0).edit().putInt("theme",w).apply();d.dismiss();Toast.makeText(this,"Tema guardado. Reinicia SONORA para aplicarlo en todas las pantallas.",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cerrar",null).show());
        settingsRow("♫","Reproducción","Calidad, reproducción y cola",()->new AlertDialog.Builder(this).setTitle("Preferencias de reproducción").setItems(new String[]{"Calidad estándar","Calidad alta (si está disponible)","Abrir cola de reproducción"},(d,w)->{if(w<2){getPreferences(0).edit().putInt("quality",w).apply();Toast.makeText(this,w==0?"Calidad estándar seleccionada":"Calidad alta seleccionada",Toast.LENGTH_SHORT).show();}else showQueueDialog();}).setNegativeButton("Cerrar",null).show());
        settingsRow("⇩","Descargas y almacenamiento",library.size()+" canciones guardadas en SONORA",()->new AlertDialog.Builder(this).setTitle("Almacenamiento").setMessage("Canciones registradas: "+library.size()+"\nLas pistas locales originales no se eliminan del teléfono.").setPositiveButton("Cerrar",null).show());
        settingsRow("♧","Notificaciones","Permisos de notificaciones del sistema",()->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},31);else new AlertDialog.Builder(this).setTitle("Notificaciones").setMessage("El permiso de notificaciones ya fue concedido o no es necesario en esta versión de Android.").setPositiveButton("Cerrar",null).show();});
        settingsRow("文","Idioma","Español",()->new AlertDialog.Builder(this).setTitle("Idioma de la interfaz").setSingleChoiceItems(new String[]{"Español","English"},getPreferences(0).getInt("language",0),(d,w)->{getPreferences(0).edit().putInt("language",w).apply();d.dismiss();Toast.makeText(this,w==0?"Español seleccionado":"English guardado; la traducción completa se incorporará en una actualización",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cerrar",null).show());
        settingsRow("ⓘ","Privacidad y acerca de","Datos guardados en este dispositivo · SONORA v1.5",()->new AlertDialog.Builder(this).setTitle("Acerca de SONORA").setMessage("SONORA — El sonido de tu mundo.\nLa biblioteca, favoritos y listas se guardan localmente. Las búsquedas de radio y catálogo necesitan conexión a Internet.").setPositiveButton("Cerrar",null).show());
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(15,15,15,15);card.setBackground(shape(panel,18));content.addView(card,lp(-1,-2,8,12));card.addView(txt("Zona de mantenimiento",15,Color.WHITE,true));Button clear=btn("Borrar biblioteca local",0xff693548,Color.WHITE);card.addView(clear,lp(-1,46,12,0));clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Borrar biblioteca").setMessage("Se quitarán de SONORA las canciones importadas y los favoritos. No se borrarán los archivos originales del teléfono.").setNegativeButton("Cancelar",null).setPositiveButton("Borrar",(d,w)->{library.clear();saveLibrary();release();nowTitle.setText("Elige una canción");nowSub.setText("SONORA PLAYER");playButton.setText("▶");page="settings";renderPage();Toast.makeText(this,"Biblioteca local borrada",Toast.LENGTH_SHORT).show();}).show());
    }
    void settingsRow(String icon,String title,String subtitle,Runnable action){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(13,11,12,11);row.setBackground(shape(panel,17));content.addView(row,lp(-1,-2,0,8));TextView i=txt(icon,23,mint,true);i.setGravity(Gravity.CENTER);row.addView(i,new LinearLayout.LayoutParams(42,42));LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(8,0,0,0);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(txt(title,14,Color.WHITE,true));words.addView(txt(subtitle,11,muted,false));row.addView(txt("›",26,muted,false));row.setOnClickListener(v->action.run());}
    void addAction(String icon,String title,String desc,Runnable action){LinearLayout card=new LinearLayout(this);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(15,13,15,13);card.setBackground(shape(panel,19));content.addView(card,lp(-1,-2,0,10));TextView ico=txt(icon,24,mint,true);ico.setGravity(Gravity.CENTER);card.addView(ico,new LinearLayout.LayoutParams(48,48));LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(10,0,0,0);card.addView(words,new LinearLayout.LayoutParams(0,-2,1));words.addView(txt(title,15,Color.WHITE,true));words.addView(txt(desc,12,muted,false));card.setOnClickListener(v->action.run());}
    void addTrackRow(Track t,int idx,boolean addToLibrary){
        LinearLayout item=new LinearLayout(this);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(12,10,10,10);item.setBackground(shape(panel,17));content.addView(item,lp(-1,-2,0,8));
        FrameLayout coverFrame=new FrameLayout(this);coverFrame.setBackground(shape(0xff353052,14));item.addView(coverFrame,new LinearLayout.LayoutParams(48,48));TextView cover=txt(t.source.equals("RADIO")?"◉":"♫",22,mint,true);cover.setGravity(Gravity.CENTER);coverFrame.addView(cover,new FrameLayout.LayoutParams(-1,-1));if(t.art!=null&&t.art.startsWith("https://")){ImageView artView=new ImageView(this);artView.setScaleType(ImageView.ScaleType.CENTER_CROP);coverFrame.addView(artView,new FrameLayout.LayoutParams(-1,-1));loadCover(t,artView,cover);}
        LinearLayout words=new LinearLayout(this);words.setOrientation(1);words.setPadding(10,0,4,0);item.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView name=txt(t.title,14,Color.WHITE,true);name.setMaxLines(1);name.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(name);TextView artist=txt(t.artist,11,muted,false);artist.setMaxLines(1);artist.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(artist);
        TextView fav=txt(t.favorite?"★":"☆",21,t.favorite?mint:muted,true);fav.setGravity(Gravity.CENTER);item.addView(fav,new LinearLayout.LayoutParams(34,42));fav.setContentDescription(t.favorite?"Quitar de favoritos":"Añadir a favoritos");
        TextView play=txt("▶",16,mint,true);play.setGravity(Gravity.CENTER);item.addView(play,new LinearLayout.LayoutParams(28,42));
        TextView more=txt("⋮",22,muted,true);more.setGravity(Gravity.CENTER);more.setContentDescription("Más opciones");item.addView(more,new LinearLayout.LayoutParams(28,42));more.setOnClickListener(v->showTrackMenu(t));
        fav.setOnClickListener(v->{t.favorite=!t.favorite;if(addToLibrary&&!containsTrack(t))library.add(t);saveLibrary();renderPage();});
        item.setOnClickListener(v->{if(addToLibrary&&!containsTrack(t)){library.add(t);saveLibrary();Toast.makeText(this,"Añadido a biblioteca",Toast.LENGTH_SHORT).show();}playTrack(t);});
    }
    void loadCover(Track t,ImageView target,TextView fallback){
        final String imageUrl=t.art;if(imageUrl==null||!imageUrl.startsWith("https://"))return;
        Bitmap cached=COVER_CACHE.get(imageUrl);if(cached!=null){target.setImageBitmap(cached);fallback.setVisibility(View.GONE);return;}
        target.setTag(imageUrl);try{network.execute(()->{Bitmap bitmap=null;HttpURLConnection conn=null;try{URL parsed=new URL(imageUrl);if(!"https".equalsIgnoreCase(parsed.getProtocol()))return;conn=(HttpURLConnection)parsed.openConnection();conn.setConnectTimeout(4000);conn.setReadTimeout(4000);conn.setInstanceFollowRedirects(false);conn.setRequestProperty("User-Agent","SonoraMusic/1.4");if(conn.getResponseCode()==200){long length=conn.getContentLengthLong();if(length<=0||length<=2*1024*1024){try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n,total=0;while((n=in.read(b))!=-1){total+=n;if(total>2*1024*1024)break;out.write(b,0,n);}if(total<=2*1024*1024){byte[] bytes=out.toByteArray();BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);if(opts.outWidth>0&&opts.outHeight>0&&opts.outWidth<=6000&&opts.outHeight<=6000){opts.inJustDecodeBounds=false;opts.inSampleSize=Math.max(1,Math.max(opts.outWidth,opts.outHeight)/512);bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);}}}}}}catch(Exception ignored){}finally{if(conn!=null)conn.disconnect();}final Bitmap result=bitmap;if(result!=null){COVER_CACHE.put(imageUrl,result);runOnUiThread(()->{if(!isFinishing()&&imageUrl.equals(target.getTag())){target.setImageBitmap(result);fallback.setVisibility(View.GONE);}});}});}catch(java.util.concurrent.RejectedExecutionException ignored){}
    }
    void showQueueDialog(){if(library.isEmpty()){new AlertDialog.Builder(this).setTitle("Cola de reproducción").setMessage("Añade canciones a tu biblioteca para crear una cola.").setPositiveButton("Aceptar",null).show();return;}String[] items=new String[library.size()];for(int i=0;i<library.size();i++)items[i]=(i==current?"▶  ":"")+library.get(i).title+" — "+library.get(i).artist;new AlertDialog.Builder(this).setTitle("Cola de reproducción · "+library.size()).setItems(items,(dialog,which)->playTrack(library.get(which))).setNegativeButton("Cerrar",null).show();}
    boolean containsTrack(Track t){for(Track x:library){if((t.uri!=null&&t.uri.equals(x.uri))||(t.url!=null&&t.url.equals(x.url)))return true;}return false;}
    void saveLibrary(){try{JSONArray a=new JSONArray();for(Track t:library){JSONObject o=new JSONObject();o.put("title",t.title);o.put("artist",t.artist);o.put("uri",t.uri==null?"":t.uri.toString());o.put("url",t.url==null?"":t.url);o.put("source",t.source);o.put("art",t.art==null?"":t.art);o.put("favorite",t.favorite);a.put(o);}getSharedPreferences("sonora_library",MODE_PRIVATE).edit().putString("tracks",a.toString()).apply();}catch(Exception ignored){}}
    void loadLibrary(){try{String raw=getSharedPreferences("sonora_library",MODE_PRIVATE).getString("tracks","[]");JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String u=o.optString("uri","");String url=o.optString("url","");Track t=new Track(o.optString("title","Audio"),o.optString("artist","Desconocido"),u.isEmpty()?null:Uri.parse(u),url.isEmpty()?null:url,o.optString("source","LOCAL"),o.optString("art",""));t.favorite=o.optBoolean("favorite",false);if(t.uri!=null|| (t.url!=null&&t.url.startsWith("https://")))library.add(t);}}catch(Exception ignored){}}
    void renderRadio(){
        content.addView(txt("Radio en vivo",24,Color.WHITE,true));
        content.addView(txt("Miles de emisoras públicas para descubrir nuevos sonidos.",13,muted,false),lp(-1,-2,4,14));
        searchBox=new EditText(this);searchBox.setSingleLine(true);searchBox.setHint("Buscar emisora, género o país");searchBox.setTextColor(Color.WHITE);searchBox.setHintTextColor(muted);searchBox.setPadding(15,10,15,10);searchBox.setBackground(shape(panel,16));content.addView(searchBox,lp(-1,52,0,8));
        Button search=btn("Buscar emisoras",purple,Color.WHITE);content.addView(search,lp(-1,48,0,10));
        status=txt("Prueba: jazz, rock, chill, noticias…",12,muted,false);content.addView(status,lp(-1,-2,0,8));
        search.setOnClickListener(v->{hideKeyboard();String q=searchBox.getText().toString().trim();fetchRadio(q);});
        addRadioGenre("Chill & Lounge","chill");addRadioGenre("Jazz","jazz");addRadioGenre("Rock","rock");addRadioGenre("Clásica","classical");
    }
    void addRadioGenre(String title,String q){Button b=btn("♫  "+title,0xff303454,Color.WHITE);content.addView(b,lp(-1,46,0,7));b.setOnClickListener(v->{searchBox.setText(q);hideKeyboard();fetchRadio(q);});}
    void fetchRadio(String q){
        if(q==null||q.trim().isEmpty()){status.setText("Escribe una emisora, género o país para buscar.");return;}
        status.setText("Buscando emisoras…");
        network.execute(()->{ArrayList<Track> result=new ArrayList<>();String error=null;
            try{String query="https://all.api.radio-browser.info/json/stations/search?name="+URLEncoder.encode(q,"UTF-8")+"&limit=25&hidebroken=true&order=clickcount&reverse=true";
                HttpURLConnection c=(HttpURLConnection)new URL(query).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","SonoraMusic/1.0");InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);JSONArray a=new JSONArray(new String(out.toByteArray(),"UTF-8"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String stream=o.optString("url_resolved",o.optString("url",""));if(stream.startsWith("https://")){String name=o.optString("name","Radio");String country=o.optString("country","");String tags=o.optString("tags","");result.add(new Track(name,country.isEmpty()?tags:country,null,stream,"RADIO"));}}c.disconnect();
            }catch(Exception e){error="No se pudo conectar. Comprueba Internet e inténtalo otra vez.";}
            final String err=error;runOnUiThread(()->{content.removeAllViews();content.addView(txt("Resultados de radio",21,Color.WHITE,true));Button back=btn("← Volver a buscar",0xff303454,Color.WHITE);content.addView(back,lp(-1,44,8,12));back.setOnClickListener(v->{page="radio";renderPage();});if(err!=null){content.addView(txt(err,14,0xffff9eaa,false));return;}if(result.isEmpty()){content.addView(txt("No encontramos emisoras HTTPS para esa búsqueda.",14,muted,false));return;}content.addView(txt(result.size()+" emisoras encontradas",12,mint,true),lp(-1,-2,0,8));for(Track t:result)addTrackRow(t,-1,true);});
        });
    }
    void renderCatalog(){
        content.addView(txt("Explorar música",24,Color.WHITE,true));
        content.addView(txt("Descubre canciones con licencia a través de Jamendo.",13,muted,false),lp(-1,-2,4,14));
        if(JAMENDO_CLIENT_ID.equals("YOUR_JAMENDO_CLIENT_ID")){
            LinearLayout info=new LinearLayout(this);info.setOrientation(1);info.setPadding(17,18,17,18);info.setBackground(shape(panel,20));content.addView(info);
            info.addView(txt("Tu próximo descubrimiento",18,Color.WHITE,true));
            TextView body=txt("El catálogo de Jamendo ofrece música independiente con licencias identificables. Para activar la búsqueda, registra una aplicación en developer.jamendo.com y coloca tu client ID en la constante JAMENDO_CLIENT_ID del código.",14,muted,false);body.setPadding(0,8,0,12);info.addView(body);
            Button guide=btn("Abrir Jamendo Developers",purple,Color.WHITE);info.addView(guide);guide.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://developer.jamendo.com/"));startActivity(i);});
        }else{
            searchBox=new EditText(this);searchBox.setSingleLine(true);searchBox.setHint("Artista, canción o género");searchBox.setTextColor(Color.WHITE);searchBox.setHintTextColor(muted);searchBox.setBackground(shape(panel,16));searchBox.setPadding(14,10,14,10);content.addView(searchBox,lp(-1,52,0,8));
            Button b=btn("Buscar catálogo",purple,Color.WHITE);content.addView(b,lp(-1,48,0,10));status=txt("",12,muted,false);content.addView(status);
            b.setOnClickListener(v->{hideKeyboard();fetchJamendo(searchBox.getText().toString().trim());});
        }
    }
    void fetchJamendo(String q){if(q==null||q.trim().isEmpty()){status.setText("Escribe un artista, canción o género.");return;}status.setText("Buscando música…");network.execute(()->{ArrayList<Track> result=new ArrayList<>();String err=null;try{String u="https://api.jamendo.com/v3.0/tracks/?client_id="+URLEncoder.encode(JAMENDO_CLIENT_ID,"UTF-8")+"&format=json&limit=25&audioformat=mp32&search="+URLEncoder.encode(q,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(12000);InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);JSONArray a=new JSONObject(new String(out.toByteArray(),"UTF-8")).getJSONArray("results");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String stream=o.optString("audio","");String art=o.optString("image"," ").trim();if(stream.startsWith("https://"))result.add(new Track(o.optString("name","Track"),o.optString("artist_name","Jamendo"),null,stream,"JAMENDO",art.startsWith("https://")?art:""));}c.disconnect();}catch(Exception e){err="No se pudo cargar el catálogo. Revisa el client ID y tu conexión.";}final String error=err;runOnUiThread(()->{content.removeAllViews();content.addView(txt("Resultados del catálogo",21,Color.WHITE,true));Button back=btn("← Volver a explorar",0xff303454,Color.WHITE);content.addView(back,lp(-1,44,8,12));back.setOnClickListener(v->{page="catalog";renderPage();});if(error!=null){content.addView(txt(error,14,0xffff9eaa,false));return;}for(Track t:result)addTrackRow(t,-1,true);if(result.isEmpty())content.addView(txt("No encontramos canciones para esa búsqueda.",14,muted,false));});});}
    void pickLocal(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,10);}
    @Override protected void onActivityResult(int r,int res,Intent d){super.onActivityResult(r,res,d);if(r==10&&res==RESULT_OK&&d!=null){if(d.getClipData()!=null){for(int i=0;i<d.getClipData().getItemCount();i++)addLocal(d.getClipData().getItemAt(i).getUri());}else if(d.getData()!=null)addLocal(d.getData());page="library";renderPage();}}
    void addLocal(Uri u){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(containsTrack(new Track("","",u,null,"LOCAL")))return;String name=u.getLastPathSegment();library.add(new Track(name==null?"Audio local":name,"En tu dispositivo",u,null,"LOCAL"));saveLibrary();}
    void play(int i){if(i>=0&&i<library.size())playTrack(library.get(i));}
    void playTrack(Track t){
        if(t==null)return;
        int found=-1;for(int i=0;i<library.size();i++){Track x=library.get(i);if((t.uri!=null&&t.uri.equals(x.uri))||(t.url!=null&&t.url.equals(x.url))){found=i;break;}}
        if(found<0){library.add(t);found=library.size()-1;saveLibrary();}
        current=found;nowTitle.setText(t.title);nowSub.setText(t.artist+"  •  "+t.source);playButton.setText("…");
        try{org.json.JSONArray arr=new org.json.JSONArray();for(Track x:library){org.json.JSONObject o=new org.json.JSONObject();o.put("title",x.title);o.put("artist",x.artist);o.put("uri",x.uri==null?"":x.uri.toString());o.put("url",x.url==null?"":x.url);o.put("source",x.source);o.put("art",x.art==null?"":x.art);arr.put(o);}Intent i=new Intent(this,MediaPlaybackService.class);i.setAction(MediaPlaybackService.ACTION_PLAY);i.putExtra("queue",arr.toString());i.putExtra("index",found);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}catch(Exception e){playButton.setText("▶");Toast.makeText(this,"No se pudo iniciar el reproductor.",Toast.LENGTH_LONG).show();}
    }
    void serviceAction(String action){Intent i=new Intent(this,MediaPlaybackService.class);i.setAction(action);try{startService(i);}catch(Exception e){Toast.makeText(this,"Abre una canción primero.",Toast.LENGTH_SHORT).show();}}
    void toggle(){if(library.isEmpty()){page="library";renderPage();pickLocal();return;}serviceAction(MediaPlaybackService.ACTION_TOGGLE);}
    void hideKeyboard(){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(searchBox.getWindowToken(),0);}catch(Exception ignored){}}
    void release(){serviceAction(MediaPlaybackService.ACTION_STOP);playing=false;}
    @Override protected void onDestroy(){try{unregisterReceiver(playbackReceiver);}catch(Exception ignored){}network.shutdownNow();super.onDestroy();}
}
