# Rediseño visual de SONORA

Esta versión incorpora una interfaz oscura con acentos violeta y turquesa, encabezado con menú principal y acceso directo a configuración, navegación por secciones, pantalla de reproductor ampliada, pantallas de favoritos, listas, perfil local y música disponible sin conexión.

## Pantallas incluidas
- Inicio
- Explorar / catálogo Jamendo (requiere configurar `JAMENDO_CLIENT_ID` para habilitar búsquedas)
- Música local
- Radio en vivo
- Listas de reproducción (crear, ver, agregar canciones y eliminar listas)
- Favoritos
- Reproductor ampliado y cola
- Descargas / música local disponible sin conexión
- Perfil local
- Configuración (apariencia guardada, preferencias de reproducción, almacenamiento, permiso de notificaciones, idioma y privacidad)

## Importante
El código fuente se actualizó, pero este entorno no dispone de Android SDK/Gradle configurado para ejecutar una compilación y una prueba en dispositivo. Por eso, el APK no se declara compilado ni probado. Ejecuta el workflow de GitHub Actions o compila desde Android Studio y revisa los registros de compilación antes de distribuirlo.
